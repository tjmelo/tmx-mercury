export declare const Notify: () => void;
