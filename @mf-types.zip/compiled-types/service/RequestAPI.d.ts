declare const instanceAPI: import("axios").AxiosInstance;
export { instanceAPI };
