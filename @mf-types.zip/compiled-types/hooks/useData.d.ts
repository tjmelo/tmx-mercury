export declare const useData: (param: string) => [];
