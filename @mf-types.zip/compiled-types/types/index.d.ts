import { ICards, ICity } from './interfaces';
import { TCard } from './types';
export type { ICards, ICity, TCard };
