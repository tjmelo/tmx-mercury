declare const Loading: () => JSX.Element;
declare const Warning: () => JSX.Element;
export { Loading, Warning };
