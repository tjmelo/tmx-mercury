import { Loading, Warning } from './Feedback';
export { Loading, Warning };
