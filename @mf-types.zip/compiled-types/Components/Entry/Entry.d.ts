import React from 'react';
declare class Entry extends React.Component {
    render(): React.JSX.Element;
}
export { Entry };
