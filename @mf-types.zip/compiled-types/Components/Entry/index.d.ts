import { Entry } from './Entry';
export { Entry as default };
