import React from 'react';
declare const State: () => React.JSX.Element;
export { State };
