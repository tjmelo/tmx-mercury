import React, { ReactNode } from 'react';
declare interface RenderResultProps {
    children: ReactNode;
}
export declare const RenderResult: React.FC<RenderResultProps>;
export {};
