import { RenderResult } from './Render';
export { RenderResult as default };
