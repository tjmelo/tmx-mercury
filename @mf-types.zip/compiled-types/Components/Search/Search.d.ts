import React, { KeyboardEventHandler } from 'react';
interface SearchProps {
    search?: KeyboardEventHandler<HTMLInputElement> | any;
}
export declare const Search: React.FC<SearchProps>;
export {};
