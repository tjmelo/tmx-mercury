import { Search } from './Search';
export { Search as default };
