import React from 'react';
declare const Router: () => React.JSX.Element;
export { Router as default };
