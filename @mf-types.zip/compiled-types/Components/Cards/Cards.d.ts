import React from 'react';
import { ICards } from '../../types';
declare const Cards: React.FC<ICards>;
export { Cards };
