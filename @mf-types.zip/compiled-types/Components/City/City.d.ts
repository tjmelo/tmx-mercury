import React from 'react';
import { ICity } from '../../types';
declare const City: React.FC<ICity>;
export { City };
