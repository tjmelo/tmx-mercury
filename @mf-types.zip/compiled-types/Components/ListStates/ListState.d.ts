import React from 'react';
export declare const ListState: () => React.JSX.Element;
